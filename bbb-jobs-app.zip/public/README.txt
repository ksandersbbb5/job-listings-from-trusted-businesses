Place your provided BBB logo at public/bbb-logo.png
(If you have the attached bluechatlogo.png already, save it here as bbb-logo.png)
