# BBB Jobs App (Next.js 14 on Vercel)

An SEO-friendly job board for **BBB Accredited Businesses**, with **Google JobPosting** structured data and search/filtering.

## Quick Start
1. **Create the repo** (GitHub) named `bbb-`.
2. **Copy files** in this project structure.
3. Add your BBB logo image to `public/bbb-logo.png`.
4. In **Vercel Project Settings → Environment Variables**, set:
   - `SHEET_URL` (or `NEXT_PUBLIC_SHEET_URL`) to your feed. Supports **JSON** _or_ **CSV** (Google Sheets Publish to Web CSV works great).
5. Install & run: `npm i` then `npm run dev`.
6. Deploy to **Vercel**. Replace `YOUR-VERCEL-DOMAIN` in `layout.tsx`, `sitemap.ts`, and job JSON-LD `url` with your domain.

### Expected Columns (flexible)
The parser is tolerant; it looks for common names. Recommended headers:
- `Business Name`, `Business URL`
- `Job Title`, `Job Category`, `Employment Type`
- `City`, `State`, `Zip`, `Street`
- `Description`
- `Date Posted`, `Valid Through`
- `Salary`
- `Apply URL`, `Apply Email`

### Google Jobs Compatibility
Each job detail page embeds a `JobPosting` JSON-LD payload. Ensure each row has at least **Job Title**, **Business Name**, and either **Apply URL** or contact **Email**. Fill location fields to maximize eligibility.

### Sitemap & Robots
A dynamic `/sitemap.xml` lists all jobs for faster indexing; `/robots.txt` allows crawling. Vercel will serve both.

### Notes
- This app fetches the sheet on-demand (no database). Use Vercel Cron if you later want to prebuild pages.
- You can whitelist states to focus on **MA, ME, RI, VT** by filtering in `app/api/jobs/route.ts` if desired.
